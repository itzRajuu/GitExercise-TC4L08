import pygame
import sys
import random

# Initialize Pygame
pygame.init()

# Load the starting song
pygame.mixer.music.load('Title_song-1.mp3')
pygame.mixer.music.play(loops=-1)

# Screen dimensions
SCREEN_WIDTH = 1280
SCREEN_HEIGHT = 750
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Slugterra Game")
main_font = pygame.font.SysFont("cambria", 50)

# Colors
PLATFORM_COLOR = (100, 50, 150)
HEALTH_BAR_COLOR = (0, 255, 0)
ENEMY_HEALTH_BAR_COLOR = (255, 0, 0)
ENEMY_BULLET_COLOR = (255, 0, 0)

# Load background images
background_image = pygame.image.load('Slug.Background.jpg')
background_image = pygame.transform.scale(background_image, (SCREEN_WIDTH, SCREEN_HEIGHT))

background_image_2 = pygame.image.load('Earth_elemental.jpg')
background_image_2 = pygame.transform.scale(background_image_2, (SCREEN_WIDTH * 2, SCREEN_HEIGHT))

# Load and scale the platform image
platform_width = 150
platform_height = 30
platform_image = pygame.image.load('platform_image.png').convert_alpha()
platform_image = pygame.transform.scale(platform_image, (platform_width, platform_height))

# Load and scale the bullet image
bullet_width = 50
bullet_height = 30
bullet_image = pygame.image.load('fire_bullet1.png').convert_alpha()
bullet_image = pygame.transform.scale(bullet_image, (bullet_width, bullet_height))

# Load enemy image
enemy_width = 50
enemy_height = 50
enemy_health = 4
enemy = pygame.Rect(SCREEN_WIDTH - 100, SCREEN_HEIGHT - 100, enemy_width, enemy_height)

enemy_image = pygame.image.load('Character/enemy.png').convert_alpha()
enemy_image = pygame.transform.scale(enemy_image, (enemy_width, enemy_height))

# Load and scale the enemy bullet image
enemy_bullet_image = pygame.image.load('enemy_bullet.png').convert_alpha()
enemy_bullet_image = pygame.transform.scale(enemy_bullet_image, (bullet_width, bullet_height))

# Initialize player variables
player_width = 50
player_height = 40
player_x = 100
player_y = SCREEN_HEIGHT - player_height - 100
player_speed = 5
player_y_velocity = 0
gravity = 1.0
jump = -20
max_jumps = 2
current_jumps = 0
player_health = 100

# Initialize player
player = pygame.Rect((player_x, player_y, player_width, player_height))
can_jump = True
can_double_jump = True

# Platform settings
initial_platform_y = SCREEN_HEIGHT - 120
platforms = []

# Coin settings
coin_size = 20
coins = []

# Enemy settings
enemy_bullets = []
enemy_last_shot_time = 0
enemy_shooting_interval = 2000

# Bullet settings
bullet_speed = 10
bullets = []
space_pressed = False

# Hit tracking
hit_count = 0
max_hits = 6

# Death flag
player_died = False

# Function to create platforms in a step-like pattern and spawn coins above them
def create_platforms_and_coins():
    for i in range(5):
        x = 200 + i * 250  # Spacing between platforms
        y = initial_platform_y - i * 50  # Decrease this value to close the gap
        platforms.append(pygame.Rect(x, y, platform_width, platform_height))
        
        # Create a coin above each platform
        coin_x = x + (platform_width - coin_size) // 2  # Center the coin
        coin_y = y - coin_size - 10  # Position the coin above the platform
        coins.append(pygame.Rect(coin_x, coin_y, coin_size, coin_size))

# Load images for character
def load_sprite_sheet(filename, frame_width, frame_height):
    sprite_sheet = pygame.image.load(filename).convert_alpha()
    frames = []
    for i in range(sprite_sheet.get_width() // frame_width):
        frame = sprite_sheet.subsurface((i * frame_width, 0, frame_width, frame_height))
        frames.append(frame)
    return frames

run_sprites = load_sprite_sheet('Character/run1.png', 37, 40)  
jump_sprites = load_sprite_sheet('Character/jump1.png', 45, 32)  
run_back_sprites = load_sprite_sheet('Character/run_back1.png', 37, 40)  
idle_sprites = load_sprite_sheet('Character/idle1.png', 37, 43)  

# Animation settings
current_frame = 0
frame_counts = {
    'run': len(run_sprites),
    'jump': len(jump_sprites),
    'run_back': len(run_back_sprites),
    'idle': len(idle_sprites)
}

action = 'idle'  
clock = pygame.time.Clock()

# Initialize coin collection variable
coins_collected = 0
level_completed = False

# Main game function
# Main game function
def main_game():
    global player_y_velocity, current_frame, current_jumps, can_jump, can_double_jump
    global bullets, player_health, enemy, enemy_bullets, enemy_last_shot_time, enemy_health, space_pressed
    global coins, coins_collected, level_completed, hit_count, max_hits, player_died

    create_platforms_and_coins()  # Create platforms and spawn coins

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

        keys = pygame.key.get_pressed()

        # Display messages when the player dies or completes the level
        if level_completed or player_died:
            screen.fill((255, 255, 255))  # Fill background

            if player_died:
                death_message = main_font.render("Hahaha noob", True, (0, 0, 0))
                screen.blit(death_message, (SCREEN_WIDTH // 2 - death_message.get_width() // 2, SCREEN_HEIGHT // 2 - death_message.get_height() // 2))
            elif level_completed:
                completion_message = main_font.render("This level is done, good luck newbie!", True, (0, 0, 0))
                screen.blit(completion_message, (SCREEN_WIDTH // 2 - completion_message.get_width() // 2, SCREEN_HEIGHT // 2 - completion_message.get_height() // 2))

            pygame.display.flip()
            clock.tick(30)
            continue  # Skip the rest of the loop when the player dies or completes the level

        # Player movement logic
        if keys[pygame.K_d]:
            player.x += player_speed
            action = 'run'
        elif keys[pygame.K_a]:
            player.x -= player_speed
            action = 'run_back'
        else:
            action = 'idle'

        if keys[pygame.K_w]:
            if can_jump:
                player_y_velocity = jump
                can_jump = False
                current_jumps = 1
                action = 'jump'
            elif can_double_jump and current_jumps < max_jumps:
                player_y_velocity = jump
                can_double_jump = False
                current_jumps += 1
                action = 'jump'

        if keys[pygame.K_SPACE]:
            if not space_pressed:
                bullet = pygame.Rect(player.right, player.y + player_height // 2 - bullet_height // 2, bullet_width, bullet_height)
                bullets.append(bullet)
                space_pressed = True
        else:
            space_pressed = False

        # Apply gravity to the player
        player_y_velocity += gravity
        player.y += player_y_velocity

        # Check collision with platforms
        on_ground = False
        for platform in platforms:
            if player.colliderect(platform) and player_y_velocity > 0:
                player.bottom = platform.top
                player_y_velocity = 0
                can_jump = True
                can_double_jump = True
                current_jumps = 0
                on_ground = True
                break

        if not on_ground and player.bottom < SCREEN_HEIGHT:
            player_y_velocity += gravity

        if player.bottom > SCREEN_HEIGHT:
            player.bottom = SCREEN_HEIGHT
            player_y_velocity = 0
            can_jump = True
            can_double_jump = True
            current_jumps = 0

        # Move bullets
        for bullet in bullets:
            bullet.x += bullet_speed
        bullets = [bullet for bullet in bullets if bullet.x < SCREEN_WIDTH]

        # Enemy shooting logic
        current_time = pygame.time.get_ticks()
        if current_time - enemy_last_shot_time > enemy_shooting_interval:
            enemy_last_shot_time = current_time
            enemy_bullet = pygame.Rect(enemy.left - bullet_width, enemy.y + enemy_height // 2 - bullet_height // 2, bullet_width, bullet_height)
            enemy_bullets.append(enemy_bullet)

        for enemy_bullet in enemy_bullets:
            enemy_bullet.x -= bullet_speed
        enemy_bullets = [enemy_bullet for enemy_bullet in enemy_bullets if enemy_bullet.x > 0]

        # Player takes damage from enemy bullets
        for enemy_bullet in enemy_bullets:
            if player.colliderect(enemy_bullet):
                hit_count += 1  # Increment hit count
                enemy_bullets.remove(enemy_bullet)
                player_health -= 100 / max_hits  # Decrease health
                if hit_count >= max_hits:
                    player_health = 0  # Set player health to 0
                    player_died = True  # Set death flag

        # Player shooting logic
        for bullet in bullets:
            if enemy.colliderect(bullet):
                enemy_health -= 1
                bullets.remove(bullet)
                if enemy_health <= 0:
                    enemy = pygame.Rect(-100, -100, enemy_width, enemy_height)

        # Collect coins
        for coin in coins[:]:  # Use a slice to avoid modifying the list while iterating
            if player.colliderect(coin):
                coins.remove(coin)  # Collect the coin
                coins_collected += 1  # Increment coins collected

        # Check if player has reached the screen width
        if player.x >= SCREEN_WIDTH - player_width:
            level_completed = True  # Set the level as completed

        # Draw everything on the screen
        screen.fill((255, 255, 255))
        screen.blit(background_image_2, (0, 0))

        if action == 'run':
            screen.blit(run_sprites[current_frame], (player.x, player.y))
        elif action == 'jump':
            screen.blit(jump_sprites[current_frame], (player.x, player.y))
        elif action == 'run_back':
            screen.blit(run_back_sprites[current_frame], (player.x, player.y))
        elif action == 'idle':
            screen.blit(idle_sprites[current_frame], (player.x, player.y))

        # Draw player bullets
        for bullet in bullets:
            screen.blit(bullet_image, bullet.topleft)

        # Draw enemy bullets using the loaded image
        for enemy_bullet in enemy_bullets:
            screen.blit(enemy_bullet_image, enemy_bullet.topleft)

        # Draw platforms and their coins
        for platform in platforms:
            screen.blit(platform_image, (platform.x, platform.y))
            # Draw the corresponding coin for each platform
            coin_x = platform.x + (platform_width - coin_size) // 2  # Center the coin
            coin_y = platform.y - coin_size - 10  # Position the coin above the platform
            if pygame.Rect(coin_x, coin_y, coin_size, coin_size) in coins:
                pygame.draw.rect(screen, (255, 215, 0), (coin_x, coin_y, coin_size, coin_size))  # Draw the coin

        # Draw enemy and health bar
        if enemy.x >= 0:
            screen.blit(enemy_image, (enemy.x, enemy.y))
            health_bar_width = 50
            health_bar_height = 5
            pygame.draw.rect(screen, (0, 0, 0), (enemy.x, enemy.y - 15, health_bar_width, health_bar_height))
            pygame.draw.rect(screen, ENEMY_HEALTH_BAR_COLOR, (enemy.x, enemy.y - 15, (enemy_health / 4) * health_bar_width, health_bar_height))

        # Draw player health bar
        health_bar_width = 200
        health_bar_height = 20
        pygame.draw.rect(screen, (0, 0, 0), (10, 10, health_bar_width, health_bar_height))
        pygame.draw.rect(screen, HEALTH_BAR_COLOR, (10, 10, (player_health / 100) * health_bar_width, health_bar_height))

        # Display coins collected
        coins_text = main_font.render(f"Coins: {coins_collected}", True, (0, 0, 0))
        screen.blit(coins_text, (10, 50))

        pygame.display.flip()
        clock.tick(30)

# Start the game
main_game()

