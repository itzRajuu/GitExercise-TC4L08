import pygame
import sys
import random

# Initialize Pygame
pygame.init()

# Initialize clock
clock = pygame.time.Clock()

# Load the starting song
pygame.mixer.music.load('Title_song-1.mp3')
pygame.mixer.music.play(loops=-1)

# Screen dimensions
SCREEN_WIDTH = 1280
SCREEN_HEIGHT = 750

screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Slugterra Game")
main_font = pygame.font.SysFont("cambria", 50)

# Colors
HEALTH_BAR_COLOR = (0, 255, 0)

# Load background images
background_image = pygame.image.load('Earth_elemental.jpg')
background_image = pygame.transform.scale(background_image, (SCREEN_WIDTH * 2, SCREEN_HEIGHT))

# Load and scale images
platform_image = pygame.image.load('platform_image.png').convert_alpha()
platform_image = pygame.transform.scale(platform_image, (150, 30))

# Load character sprite sheets
def load_sprite_sheet(filename, width, height):
    sprite_sheet = pygame.image.load(filename).convert_alpha()
    sprites = []
    sheet_width, sheet_height = sprite_sheet.get_size()

    for y in range(0, sheet_height, height):
        for x in range(0, sheet_width, width):
            if x + width <= sheet_width and y + height <= sheet_height:
                sprites.append(sprite_sheet.subsurface(pygame.Rect(x, y, width, height)))
            else:
                break  # Stop if the next sprite would be outside the sheet
    return sprites

# Load specific sprite sheets
run_sprites = load_sprite_sheet('Character/run1.png', 37, 40)
jump_sprites = load_sprite_sheet('Character/jump1.png', 45, 32)
run_back_sprites = load_sprite_sheet('Character/run_back1.png', 37, 40)
idle_sprites = load_sprite_sheet('Character/idle1.png', 37, 43)

# Initialize player variables
player_width = 50
player_height = 40
player_x = 100
player_y = SCREEN_HEIGHT - player_height - 100
player_speed = 3
player_y_velocity = 0
gravity = 1.0
jump = -20
max_jumps = 2
current_jumps = 0
player_health = 100
shooting = False

# Initialize player
player = pygame.Rect((player_x, player_y, player_width, player_height))
can_jump = True
can_double_jump = True

# Load trap images
trap_image = pygame.image.load('spike_trap.jpg').convert_alpha()
trap_image = pygame.transform.scale(trap_image, (50, 50))
traps = []

# Function to create traps
def create_traps():
    global traps
    traps.clear()
    for _ in range(2):
        trap_x = random.randint(100, SCREEN_WIDTH - 150)
        trap_y = SCREEN_HEIGHT - 100  # Move traps up by 50 pixels
        trap_rect = pygame.Rect(trap_x, trap_y, 50, 50)
        traps.append(trap_rect)

# Load enemy variables
enemy_width = 50
enemy_height = 50
enemy_health = 4
enemy = pygame.Rect(SCREEN_WIDTH - 100, SCREEN_HEIGHT - 100, enemy_width, enemy_height)

# Function to check trap collision
def check_trap_collision():
    global player_health
    for trap in traps:
        if player.colliderect(trap):
            player_health -= 20
            traps.remove(trap)
            if player_health <= 0:
                return True
    return False

def render_traps():
    for trap in traps:
        screen.blit(trap_image, trap)

def shoot_bullets(bullets):
    for bullet in bullets:
        bullet.x += 10  # Move bullet to the right
        if bullet.x > SCREEN_WIDTH:
            bullets.remove(bullet)

# Main menu function
def main_menu():
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN:
                    pygame.mixer.music.stop()
                    return

        screen.fill((0, 0, 0))
        title_text = main_font.render("Welcome to Slugterra Game", True, (255, 255, 255))
        start_text = main_font.render("Press Enter to Start", True, (255, 255, 255))
        screen.blit(title_text, (SCREEN_WIDTH // 2 - title_text.get_width() // 2, SCREEN_HEIGHT // 2 - title_text.get_height() // 2 - 20))
        screen.blit(start_text, (SCREEN_WIDTH // 2 - start_text.get_width() // 2, SCREEN_HEIGHT // 2 + 20))

        pygame.display.flip()
        clock.tick(30)

# Level selection function using buttons
def level_selection_menu():
    levels = ["Level 1"]
    buttons = []
    button_height = 50
    button_width = 300
    button_y_start = SCREEN_HEIGHT // 2 - (len(levels) * button_height) // 2

    for i, level in enumerate(levels):
        button_rect = pygame.Rect(SCREEN_WIDTH // 2 - button_width // 2, button_y_start + i * button_height, button_width, button_height)
        buttons.append((level, button_rect))

    selected_level = None

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:  # Left mouse button
                mouse_pos = event.pos
                for i, (level, rect) in enumerate(buttons):
                    if rect.collidepoint(mouse_pos):
                        selected_level = i
                        return selected_level  # Return the selected level

        screen.fill((0, 0, 0))
        title_text = main_font.render("Select Level", True, (255, 255, 255))
        screen.blit(title_text, (SCREEN_WIDTH // 2 - title_text.get_width() // 2, 100))

        for level, rect in buttons:
            pygame.draw.rect(screen, (100, 100, 255), rect)  # Button color
            level_text = main_font.render(level, True, (255, 255, 255))
            screen.blit(level_text, (rect.x + rect.width // 2 - level_text.get_width() // 2, rect.y + rect.height // 2 - level_text.get_height() // 2))

        pygame.display.flip()
        clock.tick(30)

# Function to load levels
def load_level(level):
    if level == 0:  # Level 1
        return [
            pygame.Rect(100, 600, platform_image.get_width(), platform_image.get_height()),
            pygame.Rect(450, 550, platform_image.get_width(), platform_image.get_height()),
            pygame.Rect(700, 500, platform_image.get_width(), platform_image.get_height()),
            pygame.Rect(900, 450, platform_image.get_width(), platform_image.get_height()),
            pygame.Rect(300, 400, platform_image.get_width(), platform_image.get_height()),
            pygame.Rect(1000, 350, platform_image.get_width(), platform_image.get_height()),
            pygame.Rect(600, 300, platform_image.get_width(), platform_image.get_height()),
            pygame.Rect(200, 250, platform_image.get_width(), platform_image.get_height()),
            pygame.Rect(800, 200, platform_image.get_width(), platform_image.get_height()),
            pygame.Rect(400, 150, platform_image.get_width(), platform_image.get_height()),
            # Full ground
            pygame.Rect(50, 650, platform_image.get_width(), platform_image.get_height()),    # New platform
            pygame.Rect(300, 620, platform_image.get_width(), platform_image.get_height()),   # New platform
            pygame.Rect(600, 670, platform_image.get_width(), platform_image.get_height()),   # New platform
            pygame.Rect(850, 620, platform_image.get_width(), platform_image.get_height()),   # New platform
        ]

def main_game():
    global player_y_velocity, current_jumps, can_jump, can_double_jump
    global player_health, shooting

    bullets = []
    selected_level = level_selection_menu()
    platforms = load_level(selected_level)  # Load platforms based on selected level
    create_traps()
    
    run_index = 0  # Index for running animation
    bg_x = 0  # Initial background X position

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    shooting = True
                    bullets.append(pygame.Rect(player.x + player.width, player.y + player.height // 4, 10, 5))  # Create a bullet
            if event.type == pygame.KEYUP:
                if event.key == pygame.K_SPACE:
                    shooting = False

        keys = pygame.key.get_pressed()

        if player_health <= 0:
            screen.fill((255, 255, 255))
            death_message = main_font.render("Game Over!", True, (0, 0, 0))
            screen.blit(death_message, (SCREEN_WIDTH // 2 - death_message.get_width() // 2, SCREEN_HEIGHT // 2 - death_message.get_height() // 2))
            pygame.display.flip()
            clock.tick(30)
            continue

        # Move player and offset world
        if keys[pygame.K_d]:
            player.x += player_speed
            run_index = (run_index + 1) % len(run_sprites)  # Update sprite index for running
            bg_x -= player_speed  # Move background left
            for platform in platforms:
                platform.x -= player_speed  # Move platform with the background
        elif keys[pygame.K_a]:
            player.x -= player_speed
            run_index = (run_index + 1) % len(run_back_sprites)  # Update sprite index for running back
            bg_x += player_speed  # Move background right
            for platform in platforms:
                platform.x += player_speed  # Move platform with the background
        else:
            run_index = 0  # Reset to idle sprite if not moving

        # Jumping Logic
        if keys[pygame.K_w]:
            if can_jump:  # Check if the player can jump
                player_y_velocity = jump  # Set the upward velocity
                can_jump = False  # Disable further jumps until landing
                current_jumps = 1
            elif current_jumps < max_jumps and can_double_jump:
                player_y_velocity = jump  # Allow double jump
                can_double_jump = False  # Disable double jump after use
                current_jumps += 1

        player_y_velocity += gravity  # Apply gravity
        player.y += player_y_velocity  # Move the player vertically

        # Platform collision detection
        on_ground = False
        for platform in platforms:
            if player.colliderect(platform) and player_y_velocity > 0:
                player.bottom = platform.top
                player_y_velocity = 0
                can_jump = True
                can_double_jump = True
                current_jumps = 0
                on_ground = True
                break

        if not on_ground and player.bottom < SCREEN_HEIGHT:
            player_y_velocity += gravity

        if player.bottom > SCREEN_HEIGHT:
            player.bottom = SCREEN_HEIGHT
            player_y_velocity = 0
            can_jump = True
            can_double_jump = True
            current_jumps = 0

        if check_trap_collision():
            player_health = 0

        # Update bullets
        shoot_bullets(bullets)

        # Clear the screen and draw the background
        screen.fill((255, 255, 255))
        screen.blit(background_image, (bg_x, 0))  # Move background
        
        # Wrap background image for parallax scrolling
        if bg_x <= -SCREEN_WIDTH:
            bg_x = 0

        # Draw platforms
        for platform in platforms:
            screen.blit(platform_image, platform)
            pygame.draw.rect(screen, (255, 0, 0), platform, 2)  # Draw outline of the platform

        render_traps()  # Draw traps normally
        
        # Draw player sprite
        if keys[pygame.K_d]:
            screen.blit(run_sprites[run_index], (player.x, player.y))  # Draw running sprite
        elif keys[pygame.K_a]:
            screen.blit(run_back_sprites[run_index], (player.x, player.y))  # Draw running back sprite
        else:
            screen.blit(idle_sprites[0], (player.x, player.y))  # Draw idle sprite
        
        # Draw bullets
        for bullet in bullets:
            pygame.draw.rect(screen, (0, 0, 0), bullet)  # Draw bullets

        # Draw player health
        health_bar_width = 200
        health_bar_height = 20
        pygame.draw.rect(screen, (0, 0, 0), (10, 10, health_bar_width, health_bar_height))
        pygame.draw.rect(screen, HEALTH_BAR_COLOR, (10, 10, (player_health / 100) * health_bar_width, health_bar_height))

        pygame.display.flip()
        clock.tick(60)

if __name__ == "__main__":
    main_menu()
    main_game()
