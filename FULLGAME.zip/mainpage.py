import pygame
import sys

# Initialize Pygame
pygame.init()

# Constants
FPS = 60
BUTTON_WIDTH, BUTTON_HEIGHT = 200, 80
MAIN_MENU_WIDTH, MAIN_MENU_HEIGHT = 1530, 840  # Size for the main menu

# Load resources
background_image = pygame.image.load('Slug.Background.jpg')
level_background_image = pygame.image.load('fire2.jpeg')
pygame.mixer.music.load('Title_song-1.mp3')
start_button_image = pygame.image.load('START.png')

# Scale the button image
start_button_image = pygame.transform.scale(start_button_image, (BUTTON_WIDTH, BUTTON_HEIGHT))

# Set up the display
def set_display(width, height, fullscreen=True):
    if fullscreen:
        return pygame.display.set_mode((0, 0), pygame.FULLSCREEN | pygame.NOFRAME)
    else:
        return pygame.display.set_mode((width, height))

# Initialize screen with main menu size
screen = set_display(MAIN_MENU_WIDTH, MAIN_MENU_HEIGHT)
WIDTH, HEIGHT = screen.get_size()

# Define a function to draw the start button
def draw_start_button(x, y):
    button_rect = pygame.Rect(x, y, BUTTON_WIDTH, BUTTON_HEIGHT)
    screen.blit(start_button_image, button_rect.topleft)
    return button_rect

# Main menu function
def main_menu():
    pygame.mixer.music.play(-1)
    start_button_rect = draw_start_button(WIDTH // 2 - BUTTON_WIDTH // 2, HEIGHT // 2 - BUTTON_HEIGHT // 2)

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if start_button_rect.collidepoint(event.pos):
                    level_selection()

        screen.fill((0, 0, 0))
        screen.blit(background_image, ((WIDTH - background_image.get_width()) // 2, (HEIGHT - background_image.get_height()) // 2))
        draw_start_button(WIDTH // 2 - BUTTON_WIDTH // 2, HEIGHT // 2 - BUTTON_HEIGHT // 2)
        pygame.display.flip()
        pygame.time.Clock().tick(FPS)

# Level selection function
def level_selection():
    global screen, WIDTH, HEIGHT
    screen = set_display(MAIN_MENU_WIDTH, MAIN_MENU_HEIGHT)
    WIDTH, HEIGHT = screen.get_size()

    while True:
        screen.blit(level_background_image, (0, 0))

        font = pygame.font.Font(None, 36)
        text = font.render('Level Selection', True, (0, 0, 0))
        screen.blit(text, (WIDTH // 2 - text.get_width() // 2, HEIGHT // 4))

        levels = ['Level 1', 'Level 2', 'Level 3', 'Level 4']
        level_buttons = []

        for i, level in enumerate(levels):
            button_rect = pygame.Rect((WIDTH - BUTTON_WIDTH) // 2, (HEIGHT // 2) + i * (BUTTON_HEIGHT + 10), BUTTON_WIDTH, BUTTON_HEIGHT)
            pygame.draw.rect(screen, (255, 255, 255), button_rect)
            text = font.render(level, True, (0, 0, 0))
            screen.blit(text, text.get_rect(center=button_rect.center))
            level_buttons.append(button_rect)

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                for i, rect in enumerate(level_buttons):
                    if rect.collidepoint(event.pos):
                        import_level(i + 1)

# Import level files
def import_level(level_num):
    global screen, WIDTH, HEIGHT

    if level_num in [1, 2]:
        # Load windowed dimensions for Levels 1 and 2
        screen = set_display(1280, 700)
    elif level_num == 3:
        # Load fullscreen without frame for Level 3
        screen = set_display(1536, 840, fullscreen=True)
    else:
        # Load windowed dimensions for Level 4
        screen = set_display(1280, 700)

    # Update WIDTH and HEIGHT after setting the display
    WIDTH, HEIGHT = screen.get_size()

    # Clear the screen to avoid artifacts
    screen.fill((0, 0, 0))

    try:
        if level_num == 1:
            # Load Level 1 here
            import level_1
        elif level_num == 2:
            # Load Level 2 here
            import level_2
        elif level_num == 3:
            # Load Level 3 here
            import level_3
        elif level_num == 4:
            import level_4
            # Load Level 4 here import level_4
    except ImportError:
        print(f"Level {level_num} could not be loaded.")

    # Reset the screen size to the original main menu size
    screen = set_display(MAIN_MENU_WIDTH, MAIN_MENU_HEIGHT)
    WIDTH, HEIGHT = screen.get_size()
    pygame.display.update()  # Update the display to reflect the new size
# Start the game
if __name__ == "__main__":
    main_menu()