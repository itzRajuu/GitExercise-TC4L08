import pygame
import sys
import time
import random

# Initialize pygame
pygame.init()

# Constants for screen dimensions and colors
SCREEN_WIDTH = 1280
SCREEN_HEIGHT = 750
info = pygame.display.Info()
screen_size = (SCREEN_WIDTH, SCREEN_HEIGHT)

screen = pygame.display.set_mode(screen_size)
pygame.display.set_caption("Slugterra")

background = pygame.image.load('Final_background.jpg')
background = pygame.transform.scale(background, (SCREEN_WIDTH, SCREEN_HEIGHT))

player_w = 60
player_h = 80
player_x = SCREEN_WIDTH // 2
player_y = SCREEN_HEIGHT - 2 * player_h
player_speed_y = 0
player_speed = 5

gravity = 0.5
jump = -10
ground_level = SCREEN_HEIGHT - player_h

font = pygame.font.Font(None, 36)

projectile_speed = 10
player_projectiles = []
enemy_projectiles = []
last_shot_time = pygame.time.get_ticks()

enemy_w = player_w
enemy_h = player_h
enemies = []
enemy_projectile_speed = 10
enemy_shoot_interval = 100
enemy_speed = 2
enemy_image = pygame.image.load('enemy_image.png')
enemy_image = pygame.transform.scale(enemy_image, (enemy_w, enemy_h))

boss_img = pygame.image.load('Final_Boss.png')
boss_w = int(player_w * 4)  # Increased boss width
boss_h = int(player_h * 4)  # Increased boss height
boss_img = pygame.transform.scale(boss_img, (boss_w, boss_h))

joules_img = pygame.image.load('joules2.png')
banger_img = pygame.image.load('banger2.png')

player_health = 5
max_health = 5

# Double jump
max_jumps = 2
current_jumps = 0

inventory = []
available_projectiles = ["normal", "Banger", "Joules"]
current_projectile_index = 0

bullet_image = pygame.image.load('fire_bullet1.png')
bullet_image = pygame.transform.scale(bullet_image, (40, 25))
banger_image = pygame.image.load('banger2.png')
banger_image = pygame.transform.scale(banger_image, (40, 25))
joules_image = pygame.image.load('joules2.png')
joules_image = pygame.transform.scale(joules_image, (40, 25))
enemy_bullet_image = pygame.image.load('enemy_bullet.png').convert_alpha()
enemy_bullet_image = pygame.transform.scale(enemy_bullet_image, (40, 25))
flipped_bullet = pygame.transform.flip(bullet_image, True, False)

projectile_properties = {
    "normal": {"speed": 12, "damage": 7, "image": bullet_image, "shot_interval": 300},
    "Banger": {"speed": 15, "damage": 100, "image": banger_image, "shot_interval": 1000},
    "Joules": {"speed": 12, "damage": 10, "image": joules_image, "shot_interval": 100},
    "enemy": {"speed": 12, "damage": 10, "image": enemy_bullet_image, "shot_interval": 100}
    }


class Projectile:
    def __init__(self, x, y, direction, projectile_type="normal"):
        self.rect = pygame.Rect(x, y, 40, 20)
        self.direction = direction
        self.type = projectile_type
        self.speed = projectile_properties[projectile_type]["speed"]
        self.damage = projectile_properties[projectile_type]["damage"]
        self.image = projectile_properties[projectile_type]["image"]

    def update(self):
        self.rect.x += self.speed * self.direction

    def draw(self, screen):
        if self.direction == 1:
            screen.blit(self.image, self.rect.topleft)
        else:
            screen.blit(pygame.transform.flip(self.image, True, False), self.rect)

class Enemy:
    def __init__(self, x, y):
        self.rect = pygame.Rect(x, y, enemy_w, enemy_h)
        self.speed = enemy_speed
        self.shoot_timer = 0
        self.health = 30
        self.speed_y = 0

    def apply_gravity(self):
        self.speed_y += gravity
        self.rect.y += self.speed_y

        if self.rect.bottom >= SCREEN_HEIGHT:
            self.rect.bottom = SCREEN_HEIGHT
            self.speed_y = 0

    def update(self, player_x):
        self.apply_gravity()

        if self.rect.left < 0:
            self.rect.left = 0
        elif self.rect.right > SCREEN_WIDTH:
            self.rect.right = SCREEN_WIDTH

        if self.rect.x < player_x:
            self.rect.x += self.speed
        elif self.rect.x > player_x:
            self.rect.x -= self.speed

        self.shoot_timer += 1

    def draw(self, screen):
        direction = 1 if player_x >= self.rect.x else -1
        if direction == 1:
            screen.blit(enemy_image, self.rect)
        else:
            screen.blit(pygame.transform.flip(enemy_image, True, False), self.rect)

        # Draw the enemy's health bar
        health_bar(screen, self.rect.x, self.rect.y - 10, self.health, 30)

    def shoot(self, player_x, player_y):
        if self.shoot_timer >= enemy_shoot_interval:
            self.shoot_timer = 0
            direction = 1 if player_x >= self.rect.x else -1
            return Projectile(self.rect.x, self.rect.y + self.rect.height / 2, direction, projectile_type="enemy")
        return None

class Boss:
    def __init__(self, x, y):
        self.rect = pygame.Rect(x, y, boss_w, boss_h)
        self.speed = enemy_speed * 1.5
        self.health = 250  # Increased boss health
        self.shoot_timer = 5
        self.jump_force = -12
        self.speed_y = 0
        self.gravity = 0.5
        self.on_ground = False

    def apply_gravity(self):
        self.speed_y += self.gravity
        self.rect.y += self.speed_y

        if self.rect.bottom >= SCREEN_HEIGHT:
            self.rect.bottom = SCREEN_HEIGHT
            self.speed_y = 0
            self.on_ground = True

    def move_towards_player(self, player_x):
        if self.rect.x < player_x:
            self.rect.x += self.speed
        elif self.rect.x > player_x:
            self.rect.x -= self.speed

    def jump_towards_player(self, player_y):
        if self.on_ground and self.rect.y > player_y:
            self.speed_y = self.jump_force
            self.on_ground = False

    def update(self, player_x, player_y):
        self.apply_gravity()
        self.move_towards_player(player_x)
        self.jump_towards_player(player_y)
        self.shoot_timer += 1

    def draw(self, screen, player_x):
        direction = 1 if player_x >= self.rect.x else -1
        if direction == 1:
            screen.blit(boss_img, self.rect)
        else:
            screen.blit(pygame.transform.flip(boss_img, True, False), self.rect)

        # Draw the boss's health bar
        health_bar(screen, self.rect.x, self.rect.y - 20, self.health, 200)

    def shoot(self, player_x, player_y):
        if self.shoot_timer >= enemy_shoot_interval / 2:
            self.shoot_timer = 0
            direction = 1 if player_x >= self.rect.x else -1
            return Projectile(self.rect.x, self.rect.y + self.rect.height / 2, direction, projectile_type="enemy")
        return None

def spawn_enemy():
    global enemies_killed
    if enemies_killed < 10:
        enemy_x = random.randint(0, SCREEN_WIDTH - enemy_w)
        enemy_y = SCREEN_HEIGHT - enemy_h - 10
        enemies.append(Enemy(enemy_x, enemy_y))

def load_sprite_sheet(filename, frame_width, frame_height):
    sprite_sheet = pygame.image.load(filename).convert_alpha()
    frames = []
    for i in range(sprite_sheet.get_width() // frame_width):
        frame = sprite_sheet.subsurface((i * frame_width, 0, frame_width, frame_height))
        frames.append(frame)
    return frames

run_sprites = load_sprite_sheet('plyridle.png', 48, 69)
jump_sprites = load_sprite_sheet('plyridle.png', 48, 69)
run_back_sprites = load_sprite_sheet('plyrback.png', 48, 69)
idle_sprites = load_sprite_sheet('plyridle.png', 48, 69)

def cutscene(dialogue, screen, top_bar_height=150, delay=0.05):
    running = True
    text_displayed = ""
    clock = pygame.time.Clock()

    for char in dialogue:
        text_displayed += char
        clock.tick(20)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    return

        pygame.draw.rect(screen, 'black', (0, 0, SCREEN_WIDTH, top_bar_height))

        text_surface = font.render(text_displayed, True, 'white')
        text_rect = text_surface.get_rect(center=(SCREEN_WIDTH // 2, top_bar_height // 2))
        screen.blit(text_surface, text_rect)

        pygame.display.flip()

        time.sleep(delay)

    while running:
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    running = False

        pygame.draw.rect(screen, 'black', (0, 0, SCREEN_WIDTH, top_bar_height))
        text_surface = font.render (text_displayed, True, 'white')
        text_rect = text_surface.get_rect(center=(SCREEN_WIDTH // 2, top_bar_height // 2))
        screen.blit(text_surface, text_rect)

        pygame.display.flip()

def health_bar(screen, x, y, health, max_health):
    bar_width = 100
    bar_height = 10
    pygame.draw.rect(screen, 'black', (x, y, bar_width, bar_height))
    fill_width = (health / max_health) * bar_width
    pygame.draw.rect(screen, 'red', (x, y, fill_width, bar_height))

def draw_inventory(screen, font):
    inventory_surface = font.render(f"Inventory: {', '.join(inventory)}", True, 'grey')
    screen.blit(inventory_surface, (10, 40))

def draw_current_projectile_type(screen, font, current_type):
    projectile_type_surface = font.render(f"Slug: {current_type}", True, 'white')
    screen.blit(projectile_type_surface, (10, 70))

def victory_screen(screen, score, achievements):
    clock = pygame.time.Clock()
    running = True

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    running = False

        screen.fill((0, 0, 0))

        # Display the victory message
        victory_text = font.render("Congratulations, you won!", True, (255, 255, 255))
        victory_text_rect = victory_text.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 - 50))
        screen.blit(victory_text, victory_text_rect)

        # Display the player's score
        score_text = font.render(f"Score: {score}", True, (255, 255, 255))
        score_text_rect = score_text.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2))
        screen.blit(score_text, score_text_rect)

        # Display the player's achievements
        achievements_text = font.render("Achievements:", True, (255, 255, 255))
        achievements_text_rect = achievements_text.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 + 50))
        screen.blit(achievements_text, achievements_text_rect)

        for i, achievement in enumerate(achievements):
            achievement_text = font.render(achievement, True, (255, 255, 255))
            achievement_text_rect = achievement_text.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 + 100 + i * 50))
            screen.blit(achievement_text, achievement_text_rect)

        pygame.display.flip()
        clock.tick(60)

def main_menu():
    clock = pygame.time.Clock()
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    running = False

        screen.fill((0, 0, 0))
        draw_text("Slugterra", font, (255, 255, 255), screen, SCREEN_WIDTH // 2 - 100, SCREEN_HEIGHT // 2 - 50)
        draw_text("Press Space to start", font, (255, 255, 255), screen, SCREEN_WIDTH // 2 - 150, SCREEN_HEIGHT // 2 + 50)
        pygame.display.flip()
        clock.tick(60)

    return True

def draw_text(text, font, color, surface, x, y):
    text_obj = font.render(text, 1, color)
    text_rect = text_obj.get_rect()
    text_rect.topleft = (x, y)
    surface.blit(text_obj, text_rect)

running = True
player_direction = 1
on_platform = False
normal_enemies_killed = 0
enemies_killed = 0
max_enemies = 5
boss_spawned = False
boss = None
enemy_spawned = 0
enemy_spawn_interval = 1000
last_enemy_spawn_time = pygame.time.get_ticks()

current_frame = 0
frame_counts = {
    'run': len(run_sprites),
    'jump': len(jump_sprites),
    'run_back': len(run_back_sprites),
    'idle': len(idle_sprites)
}

action = 'idle'

while running:
    current_time = pygame.time.get_ticks()

    player_rect = pygame.Rect(player_x, player_y, player_w , player_h)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_w:
                if player_y == ground_level or current_jumps < max_jumps:
                    player_speed_y = jump
                    current_jumps += 1
                    action = 'jump'
            if event.key == pygame.K_SPACE:
                shot_interval = projectile_properties[available_projectiles[current_projectile_index]]["shot_interval"]
                if current_time - last_shot_time >= shot_interval:
                    projectile = Projectile(player_x + (player_w // 2) - 20, player_y + (player_h // 2), player_direction, available_projectiles[current_projectile_index])
                    player_projectiles.append(projectile)
                    last_shot_time = current_time
            if event.key == pygame.K_e:
                current_projectile_index = (current_projectile_index + 1) % len(available_projectiles)
            if event.key == pygame.K_q:
                current_projectile_index = (current_projectile_index - 1) % len(available_projectiles)

    keys = pygame.key.get_pressed()
    player_speed_y += gravity
    player_y += player_speed_y

    if player_y > ground_level:
        player_y = ground_level
        player_speed_y = 0
        current_jumps = 0

    if keys[pygame.K_a]:
        player_x -= player_speed
        player_direction = -1
        action = 'run_back'
    elif keys[pygame.K_d]:
        player_x += player_speed
        player_direction = 1
        action = 'run'
    else:
        action = 'idle'

    player_x = max(0, min(player_x, SCREEN_WIDTH - player_w))

    screen.blit(background, (0, 0))

    for projectile in player_projectiles[:]:
        projectile.update()
        if projectile.rect.x < 0 or projectile.rect.x > SCREEN_WIDTH:
            player_projectiles.remove(projectile)
        projectile.draw(screen)

    if enemy_spawned < max_enemies and len(enemies) == 0:
        spawn_enemy()
        enemy_spawned += 1

    for enemy in enemies[:]:
        enemy.update(player_x)
        enemy.draw(screen)

        enemy_projectile = enemy.shoot(player_x, player_y)
        if enemy_projectile:
            enemy_projectiles.append(enemy_projectile)

        for projectile in player_projectiles[:]:
            if projectile.rect.colliderect(enemy.rect):
                enemy.health -= projectile.damage
                player_projectiles.remove(projectile)

                if enemy.health <= 0:
                    enemies.remove(enemy)
                    enemies_killed += 1

                if enemies_killed == max_enemies and not boss_spawned:
                    boss = Boss(SCREEN_WIDTH // -8 - boss_w // 2, SCREEN_HEIGHT - boss_h - 100)
                    boss_spawned = True

                break

    if boss:
        boss.update(player_x, player_y)
        boss.draw(screen, player_x)

        boss_projectile = boss.shoot(player_x, player_y)
        if boss_projectile:
            enemy_projectiles.append(boss_projectile)

        if player_rect.colliderect(boss.rect):
            cutscene("You got touched by the boss!", screen)
            running = False

        for projectile in player_projectiles[:]:
            if projectile.rect.colliderect(boss.rect):
                boss.health -= projectile.damage
                player_projectiles.remove(projectile)

                if boss.health <= 0:
                    # Calculate the player's score
                    score = 1000 + len(player_projectiles) * 100

                    # Calculate the player's achievements
                    achievements = []
                    if score > 2000:
                        achievements.append("High Score!")
                    if len(player_projectiles) > 10:
                        achievements.append("Projectile Master!")

                    # Display the victory screen
                    victory_screen(screen, score, achievements)

                    # Restart the game
                    main_menu()
                    running = False
                break

    for enemy_projectile in enemy_projectiles[:]:
        enemy_projectile.update()
        if enemy_projectile.rect.x < 0:
            enemy_projectiles.remove(enemy_projectile)
        enemy_projectile.draw(screen)

        if enemy_projectile.rect.colliderect(player_rect):
            player_health -= 1
            enemy_projectiles.remove(enemy_projectile)
            if player_health <= 0:
                cutscene("You died!!", screen)
                running = False

    for player_projectile in player_projectiles[:]:
        for enemy_projectile in enemy_projectiles[:]:
            if player_projectile.rect.colliderect(enemy_projectile.rect):
                player_projectiles.remove(player_projectile)
                enemy_projectiles.remove(enemy_projectile)
                break

    if action == 'run':
        screen.blit(run_sprites[current_frame], (player_x, player_y))
    elif action == 'run_back':
        screen.blit(run_back_sprites[current_frame], (player_x, player_y))
    elif action == 'jump':
        if player_direction == 1:
            screen.blit(jump_sprites[current_frame], (player_x, player_y))
        else:
            flipped_jump = pygame.transform.flip(jump_sprites[current_frame], True, False)
            screen.blit(flipped_jump, (player_x, player_y))
    else:
        if player_direction == 1:
            screen.blit(idle_sprites[current_frame], (player_x, player_y))
        else:
            flipped_idle = pygame.transform.flip(idle_sprites[current_frame], True, False)
            screen.blit(flipped_idle, (player_x, player_y))

    draw_inventory(screen, font)
    draw_current_projectile_type(screen, font, available_projectiles[current_projectile_index])
    health_bar(screen, 10, 10, player_health, max_health)

    pygame.display.flip()
    pygame.time.Clock().tick(60)



pygame.quit()
sys.exit()